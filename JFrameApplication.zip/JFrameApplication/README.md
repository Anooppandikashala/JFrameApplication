# JFrameApplication

## Screenshots
![Screenshot 1](https://github.com/Anooppandikashala/JFrameApplication/blob/master/scrnshot.png)
